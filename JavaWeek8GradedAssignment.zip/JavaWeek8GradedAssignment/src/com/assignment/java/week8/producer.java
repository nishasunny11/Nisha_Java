package com.assignment.java.week8;

public class producer {

	Thread1 t1;

	producer(Thread1 t1) {
		this.t1 = t1;
	}
}
